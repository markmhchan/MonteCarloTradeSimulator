﻿// Software Disclaimer
// End User License Agreement
//
// © 2017 Mark M.H. Chan
//
// This SOFTWARE PRODUCT is provided by Mark M.H. Chan "as is" and "with all faults." 
// By downloading and/or using it, you agree the following:
//
// Mark M.H. Chan makes no representations or warranties of any kind concerning the safety, suitability, 
// lack of viruses, inaccuracies, typographical errors, or other harmful components of this SOFTWARE PRODUCT. 
// There are inherent dangers in the use of any software, and you are solely responsible for determining whether 
// this SOFTWARE PRODUCT is compatible with your equipment and other software installed on your equipment.You are 
// also solely responsible for the protection of your equipment and backup of your data, and Mark M.H. Chan will not be 
// liable for any damages and/or losses you may suffer in connection with using, modifying, or distributing this 
// SOFTWARE PRODUCT. This SOFTWARE PRODUCT is for educational purpose only.It is NOT meant to be for trading advice.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.IO;

namespace MonteCarloSim
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void button_Click(object sender, RoutedEventArgs e)
    {
        if (tb.Text != "")
        {
            List<List<KeyValuePair<double, double>>> resultList = go(tb.Text);

            equity.DataContext = resultList[0];
            drawdown.DataContext = resultList[1];
        }
    }

    private List<List<KeyValuePair<double, double>>> go(string txt)
    {
        List<double> pl = new List<double>();
        string[] tmp = txt.Split(new[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);
        foreach(var t in tmp)
        {
            double d;
            if (Double.TryParse(t, out d)) // make sure each entry is a number
            {
                pl.Add(d);
            }
        }

        return MakeLineSeries(pl);
    }

    // make Line series for equity and max drawdown
    private List<List<KeyValuePair<double, double>>> MakeLineSeries(List<double> pl)
    {
        int simNum = 5000;  // number of simulations

        List <double> eqFinal = new List<double>();
        List <double> mdd = new List<double>();
        List<KeyValuePair<double, double>> eqKVlist = new List<KeyValuePair<double, double>>();
        List<KeyValuePair<double, double>> mddKVlist = new List<KeyValuePair<double, double>>();

        Random rnd = new Random(DateTime.Now.Millisecond);

        for (int i = 0; i < simNum; i++)
        {
            List<double> shuffled = shuffle(pl, rnd);   // shuffle (bootstrap) the P&L list as per Monte Carlo method describes
                List<double> eqlist = new List<double>();

            double equity = 1;          // equity starts at 1 or 100%
            foreach (var s in shuffled) // calculate equity line based on shuffled P&L list
            {
                eqlist.Add((s / 100 + 1) * equity);
                equity = eqlist[eqlist.Count - 1];
            }
            eqFinal.Add(equity);            // record the final equity of each sim iteration
            mdd.Add(Maxdrawdown(eqlist));   // get the maximum drawdown % from this sim iteration
        }

        var eqFinalSorted = eqFinal.OrderBy(d => d).ToList();   // sort the final equity of each sim iteration in ASC
        var mddSorted = mdd.OrderBy(d => d).ToList();       // sort the maximum drawdown % of each sim iteration in ASC
        for (int i = 0; i < simNum; i++)
        {
            // KeyValuePair<double, double> : percentile, sorted value
            eqKVlist.Add(new KeyValuePair<double, double>((i + 1) / (double)simNum * 100, eqFinalSorted[i]) );
            mddKVlist.Add(new KeyValuePair<double, double>((i + 1) / (double)simNum * 100, mddSorted[i]) );
        }

        return new List<List<KeyValuePair<double, double>>> { eqKVlist, mddKVlist }; // return for chart display
    }

    private double Maxdrawdown(List<double> eqlist)
    {
        int count = eqlist.Count;
        double mdd_ratio = 0;
        double peak = 0;
        for (int i = 0; i < count; i++)
        {
            if (eqlist[i] >= peak)  // if current equity peak > last equity peak
            {
                peak = eqlist[i];   // record peak equity 
            }
            if ((eqlist[i] - peak) / eqlist[i] < mdd_ratio)    // if last max drawdown < current max drawdown
            {
                mdd_ratio = (eqlist[i] - peak) / peak; // record max drawdown
            }
        }
        return mdd_ratio * 100; // return max drawdown %
    }

    private List<double> shuffle(List<double> pl, Random rnd)
    {
        int count = pl.Count;
        List<double> shuffled = new List<double>();
        for (int i = 0; i < count; i++) // shuffle (bootstrap) P&L from the P&L list
            {
            shuffled.Add(pl[rnd.Next(count)]);
        }

        return shuffled;
    }

    private void tb_TextChanged(object sender, TextChangedEventArgs e)
    {
        if (tb.Text != "")
            button.IsEnabled = true;    // if TextBox isn't empty, enable Go button
        else
            button.IsEnabled = false;   // if TextBox is empty, disable Go button
    }

    private void Save_Click(object sender, RoutedEventArgs e)
    {
        Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
        dlg.DefaultExt = ".txt";
        dlg.Filter = "Text documents (.txt)|*.txt";
        if (dlg.ShowDialog() == true)
        {
            string filename = dlg.FileName;

            StreamWriter writer = new StreamWriter(filename);
            writer.Write(tb.Text);  //write TextBox Text to a file
            writer.Dispose();
            writer.Close();
        }
    }

    private void Open_Click(object sender, RoutedEventArgs e)
    {
        Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();

        dlg.DefaultExt = ".txt";
        dlg.Filter = "Text documents (.txt)|*.txt";

        Nullable<bool> result = dlg.ShowDialog();

        if (result == true)
        {
            string filename = dlg.FileName;
            tb.Text = File.ReadAllText(filename);   // read text file into TextBox
        }
    }

    private void Exit_Click(object sender, RoutedEventArgs e)
    {
        this.Close();
    }

    private void About_Click(object sender, RoutedEventArgs e)
    {
        MessageBox.Show("Monte Carlo Trade Simulator 1.0\n\n© 2017 Mark M.H. Chan");
    }

    private void Help_Click(object sender, RoutedEventArgs e)
    {
        MessageBox.Show("1. Enter profit/loss % of trades, and each trade per line in the Text Box. \n\n2. Click GO button");
    }
  }
}
