Software Disclaimer
End User License Agreement

� 2017 Mark M.H. Chan

This SOFTWARE PRODUCT is provided by Mark M.H. Chan "as is" and "with all faults." 
By downloading and/or using it, you agree the following:

Mark M.H. Chan makes no representations or warranties of any kind concerning the safety, suitability, 
lack of viruses, inaccuracies, typographical errors, or other harmful components of this SOFTWARE PRODUCT. 
There are inherent dangers in the use of any software, and you are solely responsible for determining whether 
this SOFTWARE PRODUCT is compatible with your equipment and other software installed on your equipment.You are 
also solely responsible for the protection of your equipment and backup of your data, and Mark M.H. Chan will not be 
liable for any damages and/or losses you may suffer in connection with using, modifying, or distributing this 
SOFTWARE PRODUCT. This SOFTWARE PRODUCT is for educational purpose only.It is NOT meant to be for trading advice.